import {r, j as e} from "./vendor-IfRri_3N.js";
import {c as o} from "./index-DDJvTLFE.js";
const n = r.forwardRef( ({className: r, children: n, hoverOnly: s=!0, backgroundColor: a, borderRadius: d=.5, isDragging: t=!1, overlay: i, fitContent: l=!1, style: c, ...b}, m) => {
    const h = t ? "neon-border-always" : s ? "neon-border-hover" : "neon-border-always";
    return e.jsxs("div", {
        ref: m,
        className: o("neon-border-wrapper", h, "neon-border-tight", r),
        style: {
            "--neon-border-radius": `${d}rem`,
            "--neon-bg-color": a,
            "--neon-content-width": l ? "auto" : "100%",
            ...c
        },
        ...b,
        children: [e.jsx("div", {
            className: "neon-border-content",
            children: n
        }), i]
    })
}
);
n.displayName = "NeonBorder";
export {n as N};
