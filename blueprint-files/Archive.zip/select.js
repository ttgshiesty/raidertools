import {bS as e, bT as a, bU as s, r as t, j as r, bV as d, bW as l, aK as i, bX as o, bY as n, bZ as c, b_ as m, b$ as p, N as f, c0 as h, c1 as b, c2 as x, aJ as N, c3 as u, c4 as y} from "./vendor-IfRri_3N.js";
import {c as j} from "./index-DDJvTLFE.js";
const w = e
  , g = s
  , v = a
  , R = t.forwardRef( ({className: e, children: a, ...s}, t) => r.jsxs(d, {
    ref: t,
    className: j("flex h-9 w-full items-center justify-between whitespace-nowrap rounded-md border border-ui-border bg-blue-dark hover:bg-blue-light px-3 py-2 text-sm font-medium text-foreground placeholder:text-beige disabled:cursor-not-allowed disabled:opacity-50 [&>span]:line-clamp-1 transition-colors", e),
    ...s,
    children: [a, r.jsx(l, {
        asChild: !0,
        children: r.jsx(i, {
            className: "h-4 w-4 opacity-50"
        })
    })]
}));
R.displayName = d.displayName;
const z = t.forwardRef( ({className: e, ...a}, s) => r.jsx(x, {
    ref: s,
    className: j("flex cursor-default items-center justify-center py-1", e),
    ...a,
    children: r.jsx(N, {
        className: "h-4 w-4"
    })
}));
z.displayName = x.displayName;
const k = t.forwardRef( ({className: e, ...a}, s) => r.jsx(u, {
    ref: s,
    className: j("flex cursor-default items-center justify-center py-1", e),
    ...a,
    children: r.jsx(i, {
        className: "h-4 w-4"
    })
}));
k.displayName = u.displayName;
const S = t.forwardRef( ({className: e, children: a, position: s="popper", ...t}, d) => r.jsx(o, {
    children: r.jsxs(n, {
        ref: d,
        className: j("relative z-[10000] max-h-96 min-w-[8rem] overflow-hidden rounded-md border border-ui-border bg-blue-dark text-foreground shadow-md data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2", "popper" === s && "data-[side=bottom]:translate-y-1 data-[side=left]:-translate-x-1 data-[side=right]:translate-x-1 data-[side=top]:-translate-y-1", e),
        position: s,
        ...t,
        children: [r.jsx(z, {}), r.jsx(c, {
            className: j("p-1", "popper" === s && "h-[var(--radix-select-trigger-height)] w-full min-w-[var(--radix-select-trigger-width)]"),
            children: a
        }), r.jsx(k, {})]
    })
}));
S.displayName = n.displayName;
const C = t.forwardRef( ({className: e, ...a}, s) => r.jsx(b, {
    ref: s,
    className: j("px-2 py-1.5 font-semibold", e),
    ...a
}));
C.displayName = b.displayName;
const J = t.forwardRef( ({className: e, children: a, ...s}, t) => r.jsxs(m, {
    ref: t,
    className: j("relative flex w-full cursor-default select-none items-center rounded-sm py-1.5 pl-2 pr-8 hover:bg-blue-light data-[highlighted]:bg-blue-light data-[disabled]:pointer-events-none data-[disabled]:opacity-50 transition-colors", e),
    ...s,
    children: [r.jsx("span", {
        className: "absolute right-2 flex h-3.5 w-3.5 items-center justify-center",
        children: r.jsx(p, {
            children: r.jsx(f, {
                className: "h-4 w-4"
            })
        })
    }), r.jsx(h, {
        children: a
    })]
}));
J.displayName = m.displayName,
t.forwardRef( ({className: e, ...a}, s) => r.jsx(y, {
    ref: s,
    className: j("-mx-1 my-1 h-px bg-muted", e),
    ...a
})).displayName = y.displayName;
export {w as S, R as a, v as b, S as c, J as d, g as e, C as f};
